local setup :

npm  install
npm start 

Dependencies:
d3  
d3-shape

Note:

* For both side border I have kept border radius to path, and created one ball which placed start of path that will hide inside part of arc, hence we have to give that ball color same as background.

* If we have label which should come in two line then for breaking purpose we have to give # 

* if  Label postion not is not as expected, then we can pass position in props

* 