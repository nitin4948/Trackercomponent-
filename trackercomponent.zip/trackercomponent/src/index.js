import React from 'react';
import ReactDOM from 'react-dom';

//import App from './App';
import StatusComponent from './statuscomponent';
import reportWebVitals from './reportWebVitals';

const props = {"title":"Place your order","subTitleBottom":"","subTitleTop":"Step 2/7","width":700,"height":350,"radius":238,"arcWidth":10,"completedColorCode":"#4cc7f4","data":[{"status":"Reservation # Confirmed","breakPointRadius":16.66,"labelTextColor":"#bac8df","x":[-3,2],"y":7,"color":"#5871a0"},{"status":"Place your # order","breakPointRadius":16.66,"labelTextColor":"#bac8df","y":5,"x":[0,15],"color":"#5871a0"},{"status":"Order # locked","breakPointRadius":16.66,"labelTextColor":"#bac8df","x":[-8,-10],"y":-5,"color":"#5871a0"},{"status":"Leaving the # Factory","breakPointRadius":16.66,"labelTextColor":"#bac8df","x":-45,"y":-5,"color":"#5871a0"},{"status":"Arriving in # the US","breakPointRadius":16.66,"labelTextColor":"#bac8df","x":[10,0],"y":-5,"color":"#5871a0"},{"status":"Prepare for # purchase","breakPointRadius":16.66,"labelTextColor":"#bac8df","x":[15,15],"y":5,"color":"#5871a0"},{"status":"Arriving # at dealer","breakPointRadius":0,"labelTextColor":"#bac8df","x":[-1,2],"color":"#5871a0"}],"currentSteps":1,"backGroundColor":"transparent","tooltipMessage":"If you have any edits to your configuration, they must be made before you submit your order payment. For changes to First Edition Reservations please contact VW Customer CARE at 1-800-822-8987."}

ReactDOM.render(
  <React.StrictMode>
    <StatusComponent {...props} />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
