import React, { Component } from 'react';
import { arc as d3Arc, pie as d3Pie } from 'd3-shape';
import './status-component.css';
import * as d3 from 'd3';

export default class StatusComponent extends Component {
  //d3 arc variable
  arc;
  // completed arc color
  completedColorCode = '#4cc7f4';
  //arc label color
  labelTextColor = '#ffffff';

  constructor(props) {
    super(props);
    this.state = {
      data: [],
      updateData: [],
      updateComponentProps: 0,
      tooltipMessage: 'text',
      tooltip: false,
    };
    this.borderLessArc = 0;
    this.reversed = false;
  }

  componentDidMount() {
    //draw arc once component mount
    this.drawChart();
  }

  drawChart() {
    let rad = this.props.radius;
    //based on width set border radius
    if (window.innerWidth < 571) {
      this.borderLessArc = 100;
      rad = rad + this.borderLessArc;
    }
    //set border radius based on break point
    this.arc = d3Arc()
      .outerRadius(function() {
        if (window.innerWidth < 571) {
          return rad + 9;
        } else {
          return rad;
        }
      })
      //set corner radius for all arc break
      .innerRadius(rad - this.props.arcWidth)
      .cornerRadius(10);
    if (window.innerWidth < 571) {
      this.arc1 = d3Arc()
        .outerRadius(rad + 10)
        .innerRadius(rad - this.props.arcWidth)
        .cornerRadius(10);
    } else {
      this.arc1 = d3Arc()
        .outerRadius(rad)
        .innerRadius(rad - this.props.arcWidth)
        .cornerRadius(5);
    }
    const pie = d3Pie()
      .sort(null)
      .startAngle(-Math.PI / 2)
      .endAngle(Math.PI / 2)
      .value(d => d.breakPointRadius / 2);
    this.setState({ updateData: pie(this.props.data) });
    this.setState({ data: pie(this.props.data) }, function(){this.selectElem()});
  }


  selectElem() {
    let _this = this;
    //start animation
    _this.arcAnimate();
    //select all arc path
    let allArcPath = d3.selectAll('.arcStatusComponentgrp g.arc');
    let allPath = d3.select('.arcStatusComponent').selectAll('.arc-base-path');
    if (allArcPath) {
      //if(_this.reversed) return;

      allArcPath.each(function(d, i) {
        if (
          d3.select('.small_c_' + i) &&
          d3.select('.small_c_' + i)._groups[0] &&
          d3.select('.small_c_' + i)._groups[0][0] != null
        ) {
          return;
        }
        //set text based on arc path
        //if(! d3.select(this).select(".small_c_"+i)){
        d3.select(this).lower();
        if (i == 0) return;
        d3.select(this)
          .append('path')
          //.attr("style", "transform: translate(-3px, 5px)")
          .attr('stroke', 'rgb(2,34,86)')
          .attr('fill', '#022256')
          .attr('class', 'small_c_' + i)
          .attr('d', function() {
            return _this.arc1(_this.dataUpdate(_this.state.updateData[i]));
          });
        // }
      });
      _this.reversed = true;
    }

    if (
      d3.select('.small_c_') &&
      d3.select('.small_c_')._groups[0] &&
      d3.select('.small_c_')._groups[0][0] != null
    ) {
      return;
    }
    let coordinates = [];
    let initialCoordinates;
    //selected path => get its cordinate and locate text using coordinates
    allPath.each(function(d, i) {
      let positions = d3
        .select(this)
        .attr('d')
        .split(',');
      if (i == 0) {
        initialCoordinates = [
          -Number(positions[0].split(/[a-zA-Z]+/g)[1]),
          -Number(positions[1].split(/[a-zA-Z]+/g)[0]) - 5,
        ];
      }
      coordinates.push([
        positions[0].split(/[a-zA-Z]+/g)[1],
        positions[1].split(/[a-zA-Z]+/g)[0],
      ]);
    });
    //coordinates.reverse();
    if (window.innerWidth > 570) {
      let temp = d3
        .selectAll('.arc')
        .data(this.state.data)
        .append('text')
        .attr('class', 'small_c_')
        .attr('dx', function(d, i) {
          if (d.data.status.search(' # ') < 0) {
            if (
              Number(coordinates[i][0]) < -80 ||
              Number(coordinates[i][0]) > 80
            ) {
              if (Number(coordinates[i][0]) < 0) {
                return -(3.4 * d.data.status.length) - 10;
              } else {
                return 3.4 * d.data.status.length + 5;
              }
            } else {
              if (Number(coordinates[i][0]) < 0) {
                return -15;
              } else {
                return 5;
              }
            }
          } else {
            if (d.data.status.search(' # ') > -1) {
              let stringArry = d.data.status.split(' # ');
              let maxLength = 0;
              stringArry.map(data => {
                if (data.length > maxLength) maxLength = data.length;
              });
              if (Number(coordinates[i][0]) < 0) {
                return -(3.4 * maxLength) - 10;
              } else {
                return 3.4 * maxLength;
              }
            }
          }
        })
        .attr('dy', function(d, i) {
          if (
            Number(coordinates[i][0]) > -80 &&
            Number(coordinates[i][0]) < 80
          ) {
            return -15;
          }
        })
        .attr('transform', function(d, i) {
          return 'translate(' + coordinates[i] + ')';
        })
        .text(function(d) {
          return d.data.status;
        })
        .attr('level', _this.props.currentSteps);
      //check if text has #, if present then break text from #
      d3.selectAll('text').each(_this.insertLinebreaks);
    } else {
      let _this = this;
      for (let ind = 0; ind < this.state.data.length; ind++) {
        if (ind == 0 || ind == this.state.data.length - 1) {
          let words = [];
          if (_this.state.data[ind].data.status.search(' # ') > -1) {
            words = _this.state.data[ind].data.status.split(' # ');
          } else {
            words.push(_this.state.data[ind].data.status);
          }
          if (ind == 0) {
            coordinates[ind][0] =
              Number(coordinates[ind][0]) - words[0].length * 0.5;
          } else {
            coordinates[ind][0] =
              Number(coordinates[ind][0]) - words[0].length * 1 - 10;
          }
          for (let j = 0; j < words.length; j++) {
            if (
              d3.selectAll('._textId_' + j + '_' + ind)._groups[0].length == 0
            ) {
              d3.select('#arc_' + ind)
                .append('text')
                .attr('transform', function(d, i) {
                  if (j != 0) {
                    if (words[0].length > words[j].length) {
                      const rem = words[0].length - words[j].length;
                      coordinates[ind][0] =
                        ind == 0
                          ? coordinates[ind][0] + rem * 0.8
                          : coordinates[ind][0] - rem * 0.8;
                    } else {
                      const rem = words[j].length - words[0].length;
                      coordinates[ind][0] =
                        ind == 0
                          ? coordinates[ind][0] - rem * 1
                          : coordinates[ind][0] + rem * 1;
                    }
                  }

                  return 'translate(' + coordinates[ind] + ')';
                })
                .style('fill', function(d) {
                  if (
                    _this.state.data[ind].data.labelTextColor &&
                    _this.state.data[ind].data.labelTextColor != ''
                  ) {
                    return _this.state.data[ind].data.labelTextColor;
                  } else {
                    return;
                  }
                })
                .style('text-anchor', function() {
                  if (ind != 0) {
                    return 'end';
                  }
                })
                .style('font-size', '30px')
                .attr('dy', function(d, i) {
                  return 30 * (j + 1);
                })
                .attr('dx', function(d, i) {
                  //return (words[j].length/2) * 12
                })
                .text(function(d) {
                  return words[j];
                })
                .attr('class', '_textId_' + j + '_' + ind)
                .style('font-family', function() {
                  if (ind == _this.props.currentSteps) {
                    return 'vwhead-bold';
                  } else {
                    return '';
                  }
                });
            }
          }
        }
      }
    }
    //_this.arcAnimate();
    if (window.innerWidth > 570) {
      //add instruction button icon if required
      _this.adjustInstructionButton('#arc_5', true);
      // _this.adjustInstructionButton('#arc_6', false);
    } else {
      // _this.adjustInstructionButton('#arc_6', false, true);
    }
  }
  dataUpdate(d) {
    let data = {};
    data.endAngle = d.startAngle + 0.02;
    data.startAngle = d.startAngle - 0.02;

    return data;
  }

  arcAnimate() {
    // Add the background arc, from 0 to 100% (tau).
    let _this = this;
    let tau = 2 * Math.PI;
    //animate each arc path using d3
    let allPath = d3.selectAll('.arcStatusComponentgrp g.arc');
    if (_this.state.data.length > 0) {
      allPath.each(function(d, i) {
        let _i = i;
        if (_this.props.currentSteps > i) {
          d3.select(this)
            .append('path')
            .attr('stroke', _this.props.completedColorCode)
            .attr('fill', _this.props.completedColorCode)
            .transition()
            .delay(500 * _i)
            .duration(600)
            .attrTween('d', function() {
              let dta = _this.state.data[_i];

              var i = d3.interpolate(dta.startAngle + 0.001, dta.endAngle);
              return function(t) {
                dta.endAngle = i(t);
                return _this.arc(dta);
              };
            });
        }
        if (i == 0 && _this.props.currentSteps == i) {
          d3.select(this)
            .append('path')
            .attr('stroke', _this.props.completedColorCode)
            .attr('fill', _this.props.completedColorCode)
            .transition()
            .delay(100 * _i)
            .duration(100)
            .attrTween('d', function() {
              let dta = {
                startAngle: _this.state.data[_i].startAngle,
                endAngle: _this.state.data[_i].startAngle + 0.05,
              };

              var i = d3.interpolate(dta.startAngle + 0.001, dta.endAngle);
              return function(t) {
                dta.endAngle = i(t);
                return _this.arc(dta);
              };
            });
        }
      });
    }
    /*.data(_this.state.data)
        .enter()
        .append("path");*/
  }

  arcTween(d, new_score) {
    var new_startAngle = Math.random() * 2 * Math.PI;
    var new_endAngle = new_startAngle + new_score * 2 * Math.PI;
    var interpolate_start = d3.interpolate(d.startAngle, new_startAngle);
    var interpolate_end = d3.interpolate(d.endAngle, new_endAngle);
    return function(t) {
      d.startAngle = interpolate_start(t);
      d.endAngle = interpolate_end(t);
      return this.arc(d);
    };
  }
  //break text if string has # // text come in next line
  insertLinebreaks = function(d, index) {
    let el = d3.select(this);
    let lvl = Number(el.attr('level'));
    let words = el.text().split(' # ');
    if (words.length > 1) {
      let parentEl = d3.select(this.parentNode);
      //let translate = el.attr("transform");
      el.remove();
      for (var i = 0; i < words.length; i++) {
        var tspan = parentEl
          .append('text')
          .text(words[i])
          .attr('transform', el.attr('transform'))
          .attr('dx', el.attr('dx'))
          .attr('dy', el.attr('dy'))
          .attr('y', function() {
            let yValue = -(15 * (words.length - 1 - i));
            if (d.data.y) {
              yValue = yValue ? Number(yValue) + d.data.y : d.data.y;
            } else {
              yValue = yValue ? yValue : null;
            }

            return yValue;
          })
          .attr('x', function() {
            let xValue = el.attr('x');
            if(d.data && d.data.x){
              if(typeof d.data.x == "object"){
                xValue = xValue ? Number(xValue) +  d.data.x[i] :  d.data.x[i];
              }else{
                xValue = xValue ? Number(xValue) +  d.data.x :  d.data.x;
              }
            }else{
              xValue = xValue ? xValue : null;
            }
            return xValue;            
          });
        if (index == lvl) {
          tspan.style('font-family', 'vwhead-bold');
        }
      }
    } else {
      if (index == lvl) {
        el.style('font-family', 'vwhead-bold');
      }
      el.attr('x', function() {
        let xValue = el.attr('x');
        if(d.data && d.data.x){
          if(typeof d.data.x == "object"){
            xValue = xValue ? Number(xValue) +  d.data.x[i] :  d.data.x[i];
          }else{
            xValue = xValue ? Number(xValue) +  d.data.x :  d.data.x;
          }
        }else{
          xValue = xValue ? xValue : null;
        }
        return xValue; 
      }).attr('y', function() {
        let yValue = el.attr('y');
        if (d.data.y) {
          yValue = yValue ? Number(yValue) + d.data.y : d.data.y;
        } else {
          yValue = yValue ? yValue : null;
        }

        return yValue;
      });
    }
  };

  //instruction button icons adjust, based on arc path
  adjustInstructionButton(arcId, status, rightEnd) {
   
    let x, y, positions;
    if (window.innerWidth > 571) {
      let selectedText = d3.select(arcId + ' text');
      positions = selectedText.attr('transform').split('(');
      positions = positions[1].split(',');
      x = Number(positions[0]);
      y = Number(positions[1].split(')')[0]);
      x = selectedText.attr('dx') ? x + Number(selectedText.attr('dx')) : x;
      y = selectedText.attr('y') ? y + Number(selectedText.attr('y')) : y;

      if (status) {
        x = x + selectedText.text().length * 2.0;
        y = y - 40;
      } else {
        x = x - selectedText.text().length * 3.2;
        y = y - 40;
      }
    } else {
      positions = d3
        .select(arcId + ' path')
        .attr('d')
        .split(',');
      x = Number(positions[0].split(/[a-zA-Z]+/g)[1]) - 15;
      y = Number(positions[1].split(/[a-zA-Z]+/g)[0]) + 10;
    }
    d3.select("#tooltipIcon")
    .style('transform', 'translate(' + (x + 20) + 'px,' + (y - 20) + 'px)');

    //document.querySelector("#icon_2").style.transform = "translate("+x+"px,"+y+"px)";
    // document.querySelector("#icon_2").style.transform = "translate(2px, 4px)"
  }

  render() {
    if (this.state.data === undefined) {
      return <div>Loading.... </div>;
    } else {
      return (
        <div className={'chartContainerStyle'}>
          <svg
            preserveAspectRatio="none"
            viewBox={`0 0 ${this.props.width} ${this.props.height +
              this.borderLessArc}`}
            className="arcStatusComponent"
          >
            <g
              className="arcStatusComponentgrp"
              transform={`translate(${this.props.width / 2}, ${(this.props
                .height +
                this.borderLessArc) /
                1.2})`}
            >
              {this.state.data.map((d, index) => (
                <g
                  className="arc"
                  id={`arc_${index}`}
                  key={`a${d.data.status}`}
                >
                  <path
                    stroke={d.data.color}
                    d={this.arc(d)}
                    fill={d.data.color}
                    id={`arcValue_${index}`}
                    className={'arc-base-path'}
                  />
                  {/* <path
                    stroke={d.data.color}
                    d={this.state.updateData[i] ? this.arc1(this.dataUpdate(this.state.updateData[i])): ""}
                    fill={d.data.color}
                    id={`arcValue_d${index}`}
                  /> */}
                </g>
              ))}
            </g>
          </svg>
          <div className="content-details">
            <label className="titleStyle stepCountStyle">
              {this.props.subTitleTop}
            </label>
            <label
              className="titleStyle heading-font"
              /*  style={{ color: this.props.labelTextColor }} */
            >
              {this.props.title}
            </label>
          </div>
        </div>
      );
    }
  }
}
